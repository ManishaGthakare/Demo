package student_rating.student_rating.EvaluationLogic;

import java.util.ArrayList;
import java.util.List;

import student_rating.student_rating.Entity.Category;

public class Evaluation {
	
	 double finalTestScore =0.0;
	 double finalQuizScore =0.0;
	 double finalLabScore =0.0;
	 double finalProjectScore =0.0;
	 static double overallScore;
	
	//here you need to write logic for to calculate the score of number of test
	
	public double getOverallTestScore(List<Category> list) {
		
		for(Category catlist : list) {
			
			ArrayList<Double> test = new ArrayList();
			test.add(catlist.getTestScore());
			
			ArrayList<Double> quiz = new ArrayList();
			quiz.add(catlist.getQuizScore());
			
			ArrayList<Double> lab = new ArrayList();
			lab.add(catlist.getLabScore());
			
			ArrayList<Double> project = new ArrayList();
			project.add(catlist.getProjectScore());
			
			
		
		for(double testScore : test){
	
	finalTestScore = (finalTestScore + (40/1)*testScore)/100.0;
	
		}
		
		
		
		for(double quizScore : quiz){
			
			finalQuizScore = (finalQuizScore + (10/1)*quizScore)/100.0;
			
				}
		
		
		
         for(double labScore : lab){
			
			finalLabScore = (finalLabScore + (20/1)*labScore)/100.0;
			
				}
         
         for(double projectScore : project){
 			
 			finalProjectScore = (finalProjectScore + (30/1)*projectScore)/100.0;
 			
 				}
       
		
		}
		
		overallScore = finalTestScore + finalQuizScore + finalLabScore + finalProjectScore ;
		
		return overallScore ; 
		
		
	}

	
	//method to call overall score;
	
	public double getOverallScore() {
	
		return overallScore;
	}
	

}
