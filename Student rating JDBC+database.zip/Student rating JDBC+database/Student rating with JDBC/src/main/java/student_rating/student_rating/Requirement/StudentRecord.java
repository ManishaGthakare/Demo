package student_rating.student_rating.Requirement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import javax.jws.soap.SOAPBinding;

import student_rating.student_rating.JDBC_Connection.ConnectionJDBC;

public class StudentRecord {
	
public void getStudentRecord() {
	
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Please Enter Student Name");
	String name = sc.next();
	
	String sql = " select sid,student_name,subject_name,overall_rating from studentrecord where student_name =\""+name+"\";";
	
	//ConnectionJDBC con= new ConnectionJDBC();
	//con.getJdbcConnection();
	
	
	PreparedStatement statement = null;
	Connection connection = null;
	
	try {

		Class.forName("com.mysql.cj.jdbc.Driver");

		// step 2 establish connection
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentrating", "root",
				"123456789");
	
		statement = connection.prepareStatement(sql);
		
		ResultSet set = statement.executeQuery();

		while (set.next()) {
			
			int id = set.getInt(1);

			String name1 = set.getString(2);

			String subject = set.getString(3);
			
			double studentrating= set.getDouble(4);
			

			System.out.println(" Student id>>  " + id);
			System.out.println(" Student name>>  " + name1);
			System.out.println("subject name>>  " + subject);
			System.out.println(" Overall Rating >>  " +studentrating);
			System.out.println("=================================================");
			

		}

	} catch (Exception e) {

		System.out.println(e);
	}

	
	
}
	
	

	
	
}
