package student_rating.student_rating.Requirement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import student_rating.student_rating.Entity.Category;
import student_rating.student_rating.EvaluationLogic.Evaluation;

public class InsertData {
	
	public void insertStudentData() {
		
		try {

			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Enter Student Id no.:");
			int Id = scanner.nextInt();
			
			System.out.println("Enter the Name:");
			String name = scanner.next();
			
			System.out.println("Enter the Subject name");
			String subject = scanner.next();
			
			System.out.println("Enter the test score");
			double testScore = scanner.nextInt();
			
			System.out.println("Enter the quiz score");
			double quizScore = scanner.nextInt();
			
			System.out.println("Enter the lab score");
			double labScore = scanner.nextInt();
			
			System.out.println("Enter the project score");
			double projectScore = scanner.nextInt();
			
			System.out.println("Calculating the overall Rating...");
			Category cat = new Category(testScore, quizScore, labScore, projectScore);
			
			List<Category> list = new ArrayList<>();
			list.add(cat);
			
			Evaluation evaluation = new Evaluation();
			double overallRating= evaluation.getOverallTestScore(list);
			
			Connection connection = null;
			PreparedStatement stmt = null;

			try {

				String sql = "insert into studentrecord(sid,student_name,subject_name,test_score,quiz_score,lab_score,project_score,overall_rating)values(?,?,?,?,?,?,?,?)";
				// step 1 load the driver class
				Class.forName("com.mysql.cj.jdbc.Driver");

				// step 2 establish connection
				connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentrating", "root",
						"123456789");

				// step 3 create sql statement
				// Statement statement = connection.createStatement();

				stmt = connection.prepareStatement(sql);
				stmt.setInt(1,Id );
				stmt.setString(2, name);
				stmt.setString(3,subject );
			
				stmt.setDouble(4, testScore);
				stmt.setDouble(5, quizScore);
				stmt.setDouble(6, labScore);
				stmt.setDouble(7, projectScore);
				stmt.setDouble(8, overallRating);

				int j = stmt.executeUpdate();

				System.out.println("Insertion And calculation done Sucessfully.....!"+j);
				
			
			
			} catch (Exception e) {
				System.out.println(e);
			}

		} catch (Throwable e) {

			System.out.println(e);
			
		}
	}
	
	

}
