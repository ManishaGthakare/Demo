package student_rating.student_rating.Requirement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import student_rating.student_rating.JDBC_Connection.ConnectionJDBC;

public class SubjectRecord {
	public void getStubjectRecord() {
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please Enter Subject Name");
		String name = sc.next(); 
		
		String sql = "select * from studentrecord where subject_name =\""+name+"\";";
	
		
		//ConnectionJDBC con= new ConnectionJDBC();
		//con.getJdbcConnection();
		
		PreparedStatement statement = null;
		Connection connection = null;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");

			// step 2 establish connection
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentrating", "root",
					"123456789");
			
			statement = connection.prepareStatement(sql);
			
			ResultSet set = statement.executeQuery();

			while (set.next()) {
				
				
				int srid = set.getInt(1);
				int id = set.getInt(2);

				String name1 = set.getString(3);

				String subject = set.getString(4);
				
				double test= set.getDouble(5);
				
				double quiz= set.getDouble(6);
				
				double lab= set.getDouble(7);
				
				double project= set.getDouble(8);
			
				double studentrating = set.getDouble(9);
				

				System.out.println(" Student id>>  " + id);
				System.out.println(" Student name>>  " + name1);
				System.out.println("Student name>>  " + subject);
				System.out.println("test score>>  " +test);
				System.out.println("Quiz Score>>  " + quiz);
				System.out.println("lab  Score>>  " + lab);
				System.out.println("project Score >>  " +project);
				System.out.println("Overall Rating>>  " +studentrating);
				
				System.out.println("=================================================");
				

			}

		} catch (Exception e) {

			System.out.println(e);
		}

		
		
	}
		
		
	}

