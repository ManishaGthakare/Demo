package student_rating.student_rating;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



import student_rating.student_rating.Entity.Category;
import student_rating.student_rating.Entity.Student;
import student_rating.student_rating.Entity.Subject;
import student_rating.student_rating.EvaluationLogic.Evaluation;
import student_rating.student_rating.Requirement.InsertData;
import student_rating.student_rating.Requirement.StudentRecord;
import student_rating.student_rating.Requirement.SubjectRecord;

public class StudentMain 
{ 
	public static void main(String[] args) {
		
		System.out.println("Please choose one of the Following Options");
		System.out.println("[1]   NEW ENROLLMENT STUDENTS");
		System.out.println("[2]   GET RECORD BY STUDENT NAME");
		System.out.println("[2]   GET RECORD BY SUBJECT NAME");
		
		
		Scanner sc = new Scanner (System.in);
		int input = sc.nextInt();
		switch (input) {
		case 1:
			System.out.println("Please enter your details ");
			InsertData data = new InsertData();
			data.insertStudentData();
			
			break;
		case 2:
			StudentRecord record =new StudentRecord();
			record.getStudentRecord();
			
			break;
			
		case 3:
			SubjectRecord record1 = new SubjectRecord();
			record1.getStubjectRecord();
			
			
			break;	
		
		default:
			System.out.println("Invalid input");
		
	}

		
	//==================================================================================================================	
		// Category(double testScore, double quizScore, double labScore, double projectScore)
		
	/*	Category cat = new Category(100.0, 100.0, 100.0, 100.0);
		Category cat1 = new Category(80.0, 80.0, 80.0, 80.0);
		Category cat2 = new Category(70.0, 70.0, 70.0, 70.0);
		
		
		List<Category> list = new ArrayList<Category>();
		list.add(cat);
		list.add(cat1);
		list.add(cat2);
		// to calculate overall score 
		Evaluation evaluation= new Evaluation();
		evaluation.getOverallTestScore(list);
		
        
		Subject subject = new Subject("ElectroField", list);
		//Subject subject2 = new Subject("chemistry", list);
		
		List<Subject> sublist = new ArrayList<>();
		sublist.add(subject);
		
		
	    double overallscore= evaluation.getOverallScore();
	    
		Student std = new Student(1, "Manisha", overallscore, sublist);
		
	       
		System.out.println("Student data : "+std.getId());
		System.out.println("Student name : "+std.getName());
		System.out.println("Student TotalScore : "+std.getOverAllScore());
		System.out.println("Student subject details : "+std.getSubject());
	*/
	//====================================================================================================================	
		
	}
}