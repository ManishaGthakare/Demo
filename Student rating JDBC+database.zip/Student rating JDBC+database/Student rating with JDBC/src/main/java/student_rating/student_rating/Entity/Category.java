package student_rating.student_rating.Entity;

public class Category {
	
	private double testScore;
	private double quizScore;
	private double labScore;
	private double projectScore;
	
	
	
	public double getTestScore() {
		return testScore;
	}



	public void setTestScore(double testScore) {
		this.testScore = testScore;
	}



	public double getQuizScore() {
		return quizScore;
	}



	public void setQuizScore(double quizScore) {
		this.quizScore = quizScore;
	}



	public double getLabScore() {
		return labScore;
	}



	public void setLabScore(double labScore) {
		this.labScore = labScore;
	}



	public double getProjectScore() {
		return projectScore;
	}



	public void setProjectScore(double projectScore) {
		this.projectScore = projectScore;
	}

	public Category() {
		
	}


	public Category(double testScore, double quizScore, double labScore, double projectScore) {
		super();
		this.testScore = testScore;
		this.quizScore = quizScore;
		this.labScore = labScore;
		this.projectScore = projectScore;
	}



	@Override
	public String toString() {
		return "Category [testScore=" + testScore + ", quizScore=" + quizScore + ", labScore=" + labScore
				+ ", projectScore=" + projectScore + "]";
	}
	
	

}
