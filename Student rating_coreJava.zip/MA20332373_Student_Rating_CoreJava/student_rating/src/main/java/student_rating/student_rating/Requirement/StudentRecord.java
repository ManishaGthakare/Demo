package student_rating.student_rating.Requirement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import student_rating.student_rating.JDBC_Connection.ConnectionJDBC;

public class StudentRecord {
	
public void getStudentRecord() {
	
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Please Enter Student Name");
	String name = sc.next();
	
	String sql = "select * from studentrating where name =" + name + ";";
	
	 ConnectionJDBC con= new ConnectionJDBC();
	 con.getJdbcConnection();
	PreparedStatement statement = null;
	Connection connection = null;
	try {
		
		statement = connection.prepareStatement(sql);
		
		ResultSet set = statement.executeQuery();

		while (set.next()) {

			int id = set.getInt(1);

			String name1 = set.getString(2);

			String lastname = set.getString(3);
			String mobileNo = set.getString(4);
			int Score = set.getInt(5);

			String grade = set.getString(6);

			System.out.println(" Student id>>  " + id);
			System.out.println(" Student name>>  " + name1);
			System.out.println("Student Rating>>  " + Score);
			System.out.println("Subject Name>>  " + Score);
			System.out.println("=================================================");
			

		}

	} catch (Exception e) {

		System.out.println(e);
	}

	
	
}
	
	

	
	
}
