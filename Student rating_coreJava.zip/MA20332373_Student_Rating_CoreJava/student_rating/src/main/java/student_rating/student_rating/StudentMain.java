package student_rating.student_rating;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



import student_rating.student_rating.Entity.Category;
import student_rating.student_rating.Entity.Student;
import student_rating.student_rating.Entity.Subject;
import student_rating.student_rating.EvaluationLogic.Evaluation;

/**
 * Hello world!
 *
 */
public class StudentMain 
{ 
	public static void main(String[] args) {
		
		//scanner
		// Category(double testScore, double quizScore, double labScore, double projectScore)
		
		Category cat = new Category(100.0, 100.0, 100.0, 100.0);
		Category cat1 = new Category(80.0, 80.0, 80.0, 80.0);
		Category cat2 = new Category(70.0, 70.0, 70.0, 70.0);
		
		
		List<Category> list = new ArrayList<>();
		list.add(cat);
		list.add(cat1);
		list.add(cat2);
		// to calculate overall score 
		Evaluation evaluation= new Evaluation();
		evaluation.getOverallTestScore(list);
		
        
		Subject subject = new Subject("ElectroField", list);
		//Subject subject2 = new Subject("chemistry", list);
		
		List<Subject> sublist = new ArrayList<>();
		sublist.add(subject);
		
		
	    double overallscore= evaluation.getOverallScore();
	    
		Student std = new Student(1, "Manisha", overallscore, sublist);
		
	       
		System.out.println("Student data : "+std.getId());
		System.out.println("Student name : "+std.getName());
		System.out.println("Student TotalScore : "+std.getOverAllScore());
		System.out.println("Student subject details : "+std.getSubject());
		
		
	}
}