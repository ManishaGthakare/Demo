package student_rating.student_rating.Entity;

import java.util.List;

public class Subject {
	
	private String subjectName;
	
	private List<Category> category;
	
	
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public List<Category> getCategory() {
		return category;
	}
	public void setCategory(List<Category> category) {
		this.category = category;
	}
	
	
	
	
	public Subject(String subjectName, List<Category> category) {
		super();
		this.subjectName = subjectName;
		this.category = category;
	}
	public Subject() {
		
	}
	
	@Override
	public String toString() {
		return "Subject [subjectName=" + subjectName + ", category=" + category + "]";
	}
	
	
	
}
