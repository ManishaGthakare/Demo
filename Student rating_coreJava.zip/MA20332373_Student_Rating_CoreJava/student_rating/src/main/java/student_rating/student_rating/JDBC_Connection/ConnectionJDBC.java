package student_rating.student_rating.JDBC_Connection;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ConnectionJDBC {
	
	public void getJdbcConnection(){
	
	Connection connection = null;
	
	
	// create connection with database
	try {
		// load the driver class
		Class.forName("com.mysql.cj.jdbc.Driver");

		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentrating", "root",
				"123456789");

	} catch (Exception e) {

		System.out.println(e);
	}
	
}

}
