package student_rating.student_rating.Entity;

import java.util.List;

import student_rating.student_rating.StudentMain;

public class Student {
	
	private int id;
	
    private String name;
    
    private double overAllScore;
    
    private List<Subject> subject;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getOverAllScore() {
		return overAllScore;
	}

	public void setOverAllScore(double overAllScore) {
		this.overAllScore = overAllScore;
	}

	public List<Subject> getSubject() {
		return subject;
	}

	public void setSubject(List<Subject> subject) {
		this.subject = subject;
	}

	public Student(int id, String name, double overAllScore, List<Subject> subject) {
		super();
		this.id = id;
		this.name = name;
		this.overAllScore = overAllScore;
		this.subject = subject;
	}

	public Student() {
		
	}

	
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", overAllScore=" + overAllScore + ", subject=" + subject + "]";
	}

   
   
    
  
}
